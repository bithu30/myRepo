The following modules are required for this chapter:

* Catalyst
* DBI
* DBIx::Class
* DateTime
* Module::Install::Catalyst
* Moose
* MooseX::MarkAsMethods
* MooseX::NonMoose
* Template
* namespace::autoclean

The following programs are included:

* listing_19_1_dbic.pl
* listing_19_2_letter.pl

There is also directory named Rights that contains our anti-DMCA application.

All programs can be run with perl programname.pl, with the exception of the
Catalyst application in the Rights/ directory. For that, change into the
Rights/ directory and run this:

 perl script/rights_server.pl
