The following modules need to be installed from the CPAN for this chapter:

* DateTime;
* Moose::Util::TypeConstraints;
* Moose;
* MooseX::StrictConstructor;
* namespace::autoclean;

The following programs (and the supporting modules) are included:

* example_13_1_person.pl
* example_13_2_episode.pl
* listing_13_1_age.pl

All programs can be run with:

 perl programname.pl
