use strict;
use warnings;
use diagnostics;

my @name = qw(Andrew Andy Kaufman);
print qq{$name[0] "$name[1]" $name[2]\n};
