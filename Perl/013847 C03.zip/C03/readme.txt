The programs included with in this folder are from Wrox' Beginning Perl,
Chpater 3. You can run all of them with:

    perl programname.pl

listing_3_5_hello.pl takes optional arguments which will be printed to the
terminal:

    perl listing_3_5_hello.pl John. Q. Public

There are no requirements for any of these files beyond Perl 5.6 or better.
Most will run even with older versions of Perl.
