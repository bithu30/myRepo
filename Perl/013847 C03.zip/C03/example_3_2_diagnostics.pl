use strict;
use warnings;
use diagnostics;
my $x;

# As with listing_3_4_diagnostics.pl, this line will generate a warning and
# diagnostics will verbosely explain the warning. The exact text of that
# warning will vary depending on your version of Perl.

print 3 / $x;
