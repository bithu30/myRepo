The following programs and modules are included with Chapter 12:

* example_12_1_shopper.pl
* example_12_2_episode.pl
* listing_12_1_episode.pl

You will need to install the DateTime module from the CPAN for these examples.

All programs can be run with perl programname.pl
