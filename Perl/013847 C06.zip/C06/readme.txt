The following files should be included with Chapter 6

* example_6_1_complex.pl
* listing_6_1_sales.pl
* listing_6_2_dclone.pl

The have no non-core dependencies and all may be run with perl programname.pl
