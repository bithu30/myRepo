The following modules are required for this chapter:

* Capture::Tiny
* HTML::Strip
* JSON::Any
* WWW::Mechanize
* utf8::all

All programs can be run with perl programname.pl
