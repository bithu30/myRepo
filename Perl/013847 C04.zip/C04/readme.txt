There is only one program for chapter 4:

* example_4_1_names.pl

It has no non-core dependencies and may be run with perl example_4_1_names.pl
