The following programs are included with Chapter 8:

* example_8_1_name_and_age.pl
* listing_8_1_data_structure.pl
* example_8_2_dates.pl
* listing_8_2_composed_regexes.pl

The "listing_8_2_composed_regexes.pl" program requires the Regexp::Common module to be
installed from the CPAN.

All programs can be run with perl programname.pl
