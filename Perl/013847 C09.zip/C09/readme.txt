The following files are included with Chapter 9.

* example_9_1_spies.pl
* example_9_2_tree.pl
* listing_9_1_targets.pl
* listing_9_2_reading_from_data.pl
* readme.txt
* spies1.txt
* spies2.txt
* spies3.txt
* spies4.txt
* targets.txt

example_9_2_tree.pl requires the autodie module to be installed from the CPAN. It should
be run as:

 perl example_9_2_tree.pl some_directory
