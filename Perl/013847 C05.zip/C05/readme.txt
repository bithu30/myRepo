There are two programs available for Chapter 5:

* example_5_1_unique.pl
* example_5_2_arrays.pl
* example_5_3_while.pl

They do not require additional software beyond Perl. They may both be run with
perl programname.pl
