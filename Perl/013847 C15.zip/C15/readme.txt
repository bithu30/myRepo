The Anne Frank Stamp is a freely available image from Wikimedia Commons
http://commons.wikimedia.org/wiki/File:Anne_Frank_stamp.jpg

The following programs are included withs this chapter:

* example_15_1_google_directions.pl
* listing_15_1_get_links.pl
* listing_15_2_get_comments.pl
* listing_15_3_post_character.pl

The following modules are required for this chapter:

- File::Slurp
- HTML::Entities
- HTML::SimpleLinkExtor
- HTML::Strip
- HTML::TableExtract
- HTML::TokeParser::Simple
- JSON::Any
- libwww-perl
- Plack
- PSGI
- Template::Tiny;
- URI::Encode
- WWW::Mechanize
- utf8::all

Individual .psgi programs  should be run with:

 plackup name.psgi

