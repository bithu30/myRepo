The following programs are included with Chapter 10:

* example_10_1_soldier.pl
* example_10_2_is_prime.pl
* example_10_3_celsius.pl
* listing_10_1_employee.pl
* listing_10_2_collate.pl
* listing_10_3_locale_sort.pl

You will need to install the following modules from the CPAN:

* ut8::all
* Unicode::Collate
* Unicode::Collate::Locale

All programs can be run with perl programname.pl
