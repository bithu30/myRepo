The following programs are included with Chapter 7

* listing_7_1_fibonacci.pl
* listing_7_2_binary_search.pl
* example_7_1_running_total.pl
* example_7_2_length.pl
* example_7_3_zip.pl
* example_7_4_maze.pl


The example_7_4_maze.pl program requires List::Util and Time;:HiRes modules,
both of which are included in Perl 5.8.0 and newer. If you have an older Perl,
those may need to be installed from the CPAN.

You can run all of these programs with perl programname.pl
